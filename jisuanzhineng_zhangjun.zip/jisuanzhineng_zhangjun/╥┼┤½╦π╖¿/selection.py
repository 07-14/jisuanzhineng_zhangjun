import numpy as np

#计算每个染色体占种群适应值总和的比
def calculate(x):
    p = [0 for i in range(len(x))]
    s = 0
    for j in x:
        s += j
    for k in range(len(x)):
        p[k] = x[k] / s
    return p

# 选择
def selection(population,fitness, m, n):
    population1 = population
    r = np.random.rand(m)
    for i in range(m):
        k = 0
        for j in range(n):
            k = k + fitness[j]
            if r[i] <= k:
                population1[i] = population[j]
                break
    return population1
