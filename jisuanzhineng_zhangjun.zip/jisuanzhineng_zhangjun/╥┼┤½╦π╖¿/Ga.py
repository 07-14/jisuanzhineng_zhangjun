from init import init 
from evaluate import evaluate 
from selection import * 
from crossover import crossover 
from mutation import mutation 
import matplotlib.pyplot as plt
import numpy

def maxf(f,x):
    m=f[0]
    xx=0
    for i in range(len(f)):
        if f[i]>m:
            m=f[i]
            xx=x[i]
    return m,xx

m=8 #种群规模
n=50#基因数
N=800 #迭代次数
matingrate=0.8 #交配概率
mutationrate=0.05 #变异概率
v=[220,208,198,192,180,180,165,162,160,158,155,130,125,122,\
    120,118,115,110,105,101,100,100,98,96,95,90,88,82,80,77,\
    75,73,72,70,69,66,65,63,60,58,56,50,30,20,15,10,8,5,3,1]
w=[80,82,85,70,72,70,66,50,55,25,50,55,40,48,50,32,22,60,30,\
    32,40,38,35,32,25,28,30,22,25,30,45,30,60,50,\
    20,65,20,25,30,10,20,25,15,10,10,10,4,4,2,1]
W=1000


pop=init(m,n)
[f,x]=evaluate(pop,w,v,W)
besty=0
bestx=[]
y=[]
for i in range(N): 
    p=calculate(f)
    pop=selection(pop,p,m,n)#选择
    pop=crossover(pop,m,n,matingrate)#遗传
    pop=mutation(pop,m,n,mutationrate)#变异
    [f,x]=evaluate(pop,w,v,W)
    [y1,xx]=maxf(f,x)
    if y1>besty:
        besty=y1
        bestx=xx
    y.append(besty)
print("最大值为：",besty,"最优解为：",bestx)
x=np.linspace(1,N,N)
plt.plot(x,y)
plt.show()



