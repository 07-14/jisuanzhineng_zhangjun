import numpy as np
##初始化群体
'''
生成m（种群规模）*n（基因数）的二维数组
取值范围为(low,high)
'''
def init(m, n): 
    population = []
    for i in range(m):
        pop=''
        for j in range(n):
            pop=pop+str(np.random.randint(0,2))
        population.append(pop)
    return population
