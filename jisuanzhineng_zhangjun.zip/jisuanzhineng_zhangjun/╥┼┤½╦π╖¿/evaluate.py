def decode(x,w,v,W):
    s=[]#储存被选择物体的下标集合
    g=0
    f=0
    for i in range(len(x)):
        if (x[i] == '1'):
            if g+w[i] <= W:
                g = g+w[i]
                f = f+v[i]
                s.append(i)
            else:
                break
    return f,s

def evaluate(population,w,v,W): 
    value=[]
    ss=[]
    for i in range(len(population)):
        [f,s]= decode(population[i],w,v,W)
        value.append(f)
        ss.append(s)
    return value,ss
