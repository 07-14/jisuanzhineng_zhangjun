import numpy as np
#变异
def mutation(population, m, n, probability):
    for i in range(m):
        for j in range(n):
            q = np.random.rand()
            if q < probability:
                population[i]=population[i][:j]+str(np.random.randint(0,2))+population[i][j+1:]
    return population
