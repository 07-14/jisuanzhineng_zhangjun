import numpy as np
##交配
def crossover(population, m, n, probability):
    r = np.random.rand(m)
    k = [0 for i in range(m)]  #记录染色体是否参与交配，交配为1，不交配为0
    for i in range(m):  #选择参加交配的染色体
        if r[i] < probability:
            k[i] = 1
    u=v=0
    k[0]=0
    for i in range(m):
        if k[i]:
            if k[u] == 0:
                u = i
            elif k[v] == 0:
                v = i
        if k[u] and k[v]:
            q = np.random.randint(n - 1)
            c=population[u][q+1:]
            population[u]=population[u][:q+1]+population[v][q+1:]
            population[v]=population[v][:q+1]+c
            k[u] = 0
            k[v] = 0
    return population

