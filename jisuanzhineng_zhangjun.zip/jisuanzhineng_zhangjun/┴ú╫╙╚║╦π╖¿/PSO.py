import random
import matplotlib.pyplot as plt
import numpy as np

class birdss:
 """
 speed:速度
 position:位置
 fit:适应度
 lbestposition:经历的最佳位置
 lbestfit:经历的最佳的适应度值
 """
 def __init__(self, speed, position, fit, lBestPosition, lBestFit):
  self.speed = speed
  self.position = position
  self.fit = fit
  self.lBestFit = lBestFit
  self.lBestPosition = lBestPosition

class PSO:
    """
    fitFunc:适应度函数
    birdNum:种群规模
    w:惯性权重
    c1,c2:个体学习因子，社会学习因子
    solutionRange:解空间，列表类型：[最小值，最大值]
    n:维度
    """

    def __init__(self, fitFunc, birdNum, w, c1, c2,solutionRange,n):
        self.fitFunc = fitFunc
        self.w = w
        self.c1 = c1
        self.c2 = c2
        self.n = n
        self.birds, self.best = self.initbirds(birdNum, solutionRange,n)

    def initbirds(self, size, solutionRange,n):
        birds = []
        for i in range(size):
            position =[0]*n
            for j in range(n):
                position[j] = random.uniform(solutionRange[0], solutionRange[1])
            speed = [0]*n
            for j in range(n):
                speed[j] = random.uniform(solutionRange[0], solutionRange[1])
            fit = self.fitFunc(position)
            print("初始化粒子",i+1,"的fit:",fit,"    position:",position)
            birds.append(birdss(speed, position, fit, position, fit))
        best = birds[0]
        for bird in birds:
            if bird.fit < best.fit:
                best = bird
        return birds, best

    def updateBirds(self,n,solutionRange):
        for bird in self.birds:
            # 更新速度
            for i in range(n):
                bird.speed[i]= self.w * bird.speed[i] + self.c1 * random.random() * (
                            bird.lBestPosition[i] - bird.position[i]) + self.c2 * random.random() * (
                                        self.best.position[i] - bird.position[i])
            # 更新位置
            for i in range(n):
                bird.position[i] = bird.position[i] + bird.speed[i]
                if bird.position[i]>solutionRange[1]:
                    bird.position[i]=solutionRange[1]
                elif bird.position[i] < solutionRange[0]:
                    bird.position[i] = solutionRange[0]
            # 更新适应度
            bird.fit = self.fitFunc(bird.position)
            # 查看是否需要更新经验最优
            if bird.fit < bird.lBestFit:
                bird.lBestFit = bird.fit
                bird.lBestPosition = bird.position

    def solve(self, maxIter,solutionRange):
        # 只考虑了最大迭代次数，如需考虑阈值，添加判断语句就好
        best=[]
        for i in range(maxIter):
            # 更新粒子
            self.updateBirds(self.n,solutionRange)
            for bird in self.birds:
                # 查看是否需要更新全局最优
                if bird.fit < self.best.fit:
                    self.best = bird
            #存储历次迭代的最优值
            best.append(self.best.fit)
        print("最优值为：",self.best.fit)
        print("最优位置为：", self.best.position)
        plt.plot(np.linspace(0, maxIter, maxIter), best, c="R", alpha=0.5)
        plt.show()

if __name__ == "__main__":
    def fitFunc(position):
        return position[0]**2+position[1]**2
    pso = PSO(fitFunc,3,0.5,2.0,2.0,[-10,10],2)
    pso.solve(5000,[-10,10])
    
