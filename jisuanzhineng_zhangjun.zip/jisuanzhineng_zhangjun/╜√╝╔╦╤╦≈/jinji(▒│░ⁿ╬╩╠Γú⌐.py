import math
import random
import numpy as np
import sys
import copy

C=500  #背包最大数
n = 20  #物品数
#物品重量和价值
w=[92,4,43,83,84,68,92,82,6,44,32,18,56,83,25,96,70,48,14,58]
c=[44,46,90,72,91,40,75,35,8,54,78,40,77,15,61,17,75,29,75,63]
#用于存储物品价值比
v=[0 for i in range(n)]
for i in range(n):
    v[i]=c[i]/w[i]
#禁忌表
tabu_list = []
tabu_time = []
#当前禁忌对象数量
current_tabu_num = 0
#禁忌长度，即禁忌期限
tabu_limit = 2

#最佳路径以及最佳距离
best_route = []
best_distance = sys.maxsize
current_route = []
current_distance = 0.0


#步骤1：贪心算法求初始背包方案
def Greedy(n,ww,v):
    select=[0 for i in range(n)]  #记录已选物品
    csum=0     #记录贪心算法所得背包价值
    wsum=ww
    k=0
    value=copy.copy(v)
    value.sort(reverse=True)
    while True:
        i=v.index(value[k])
        csum=csum+c[i]
        wsum=wsum-w[i]
        select[i]=1
        k+=1
        if w[i]>wsum:
            break
    return (select)


#计算总距离
def cacl_best(rou):
    csum = 0.0
    wsum=0
    for i in range(n):
        if rou[i]==1:
            csum += c[i]
            wsum += w[i]
    if wsum<=C:
        return csum
    else:
        return 0

#初始设置
def setup():
    global best_route
    global best_distance
    global tabu_time
    global current_tabu_num
    global current_distance
    global current_route
    global tabu_list
    #得到初始解以及初始距离
    current_route = Greedy(20,C,v)
    best_route = copy.copy(current_route)
    #函数内部修改全局变量的值
    current_distance = cacl_best(current_route)
    best_distance = current_distance
    
    #置禁忌表为空
    tabu_list.clear()
    tabu_time.clear()
    current_tabu_num = 0

#交换数组第i个物品，放变成不放，不放变成放
def exchange(index, arr):
    current_list = copy.copy(arr)
    current_list[index]=1 - current_list[index]
    return current_list

#得到邻域 候选解
def get_candidate():
    global best_route
    global best_distance
    global current_tabu_num
    global current_distance
    global current_route
    global tabu_list
    global c
    #候选集
    candidate=[]
    candidate_distance = []
    temp=0
    can_index=[0 for i in range(n)]
    for i in range(n):
        if i not in tabu_list:
            candidate.append(exchange(i, current_route))
            cmax=cacl_best(candidate[temp])
            if cmax!=0:
                candidate_distance.append(cmax)
                can_index[i]=temp
                temp+=1
            else:
                candidate.remove(candidate[temp])

    #得到候选解中的最优解
    if candidate_distance:
        candidate_best = max(candidate_distance)
    else:
        candidate_best =candidate_best
    best_index = candidate_distance.index(candidate_best)
    
    current_distance = candidate_best
    current_route = copy.copy(candidate[best_index])
    #与当前最优解进行比较 
    
    if current_distance > best_distance:
        best_distance = current_distance
        best_route = copy.copy(current_route)
        
    #加入禁忌表
    tabu_list.append(can_index.index(best_index))
    tabu_time.append(tabu_limit)
    current_tabu_num += 1

    candidate.clear()
    candidate_distance.clear()
    can_index.clear()
    
#更新禁忌表以及禁忌期限
def update_tabu():
    global current_tabu_num
    global tabu_time
    global tabu_list
    del_num = 0
    temp = []
    
    #如果达到期限，释放
    for i in range(current_tabu_num):
        if tabu_time[i] == 0:
            del_num += 1
            temp = tabu_list[i]
           
    current_tabu_num -= del_num        
    while 0 in tabu_time:
        tabu_time.remove(0)
    
    while temp in tabu_list:
        tabu_list.remove(temp)

    
    #更新步长
    tabu_time = [x-1 for x in tabu_time]
    

                
def solve():
    runtime = 25 #迭代次数
    setup()
    for rt in range(runtime):
        get_candidate()
        update_tabu()
    print("最大背包价值的物品选择方案：")    
    print(best_route)
    print("最大背包价值：",best_distance)
    
if __name__=="__main__":
    solve()
    

